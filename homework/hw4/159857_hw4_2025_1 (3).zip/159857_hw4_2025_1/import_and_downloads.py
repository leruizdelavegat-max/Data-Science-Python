import os
import json
import requests

# URL base del directorio en LAADS DAAC
SOURCE_URL = "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/61/MOD44B/2024/065"

# Ruta local donde se guardarán los archivos
DESTINATION_DIR = r"C:\JOSE\UP\ciclo 9\PHYTOM UP\159857_homework4"

# Token actualizado (NO LO COMPARTAS públicamente)
TOKEN = "eyJ0eXAiOiJKV1QiLCJvcmlnaW4iOiJFYXJ0aGRhdGEgTG9naW4iLCJzaWciOiJlZGxqd3RwdWJrZXlfb3BzIiwiYWxnIjoiUlMyNTYifQ.eyJ0eXBlIjoiVXNlciIsInVpZCI6ImphLnphbWJyYW5vMDciLCJleHAiOjE3NTQxMzk0MzYsImlhdCI6MTc0ODk1NTQzNiwiaXNzIjoiaHR0cHM6Ly91cnMuZWFydGhkYXRhLm5hc2EuZ292IiwiaWRlbnRpdHlfcHJvdmlkZXIiOiJlZGxfb3BzIiwiYWNyIjoiZWRsIiwiYXNzdXJhbmNlX2xldmVsIjozfQ.2LnwvuFQgZIntDcwnqhEFjH1D29WDATYLCCeWMK8mp5sfyLxNlTf-c4XyK31DyxDWPbKIZJfGiFLrpUwfLdf6j8yQzM95A-4-4jPZQMX1JCxZajGhzsfe4VJyKP-GA5XaScRbkMZEY5gcEHdTF4DSsRtfxQm0t77smFpY9IOGTNM1dRsq4SYGttuY3rW6tD7WPjwBQ-yQolCdjKkq5y2VVoV83uw_GvAb-6m9lfElTFsFea9lg7d7dZwTw2ApVXAK7dnMdiVA4M9WYiHH4IIYeT_t_nY-T69rD39AndhdESS-_DXPBk2BVu-sU59vqVvKE_rGb2_s6S0HZyMVbdhTg"

# ✅ Tiles que cubren Perú
tiles_peru = {"h10v09", "h10v10", "h11v09", "h11v10"}

# 🔐 Token de autenticación (NO lo compartas en público)
TOKEN = "eyJ0eXAiOiJKV1QiLCJ..."  # Truncado por privacidad
HEADERS = {"Authorization": f"Bearer {TOKEN}"}

def get_file_list():
    print("📦 Obteniendo lista de archivos disponibles...")
    response = requests.get(SOURCE_URL + ".json", headers=HEADERS)
    response.raise_for_status()
    return response.json()["content"]

def download_file(filename):
    url = f"{SOURCE_URL}/{filename}"
    local_path = os.path.join(DESTINATION_DIR, filename)
    if os.path.exists(local_path):
        print(f"✅ Ya existe, se omite: {filename}")
        return
    print(f"⬇️  Descargando: {filename}")
    with requests.get(url, headers=HEADERS, stream=True) as r:
        if r.status_code != 200:
            print(f"⚠️ Error {r.status_code} al descargar {filename}")
            return
        with open(local_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

def main():
    os.makedirs(DESTINATION_DIR, exist_ok=True)
    file_list = get_file_list()
    for file in file_list:
        if int(file["size"]) == 0:
            continue
        # ✅ Solo descargar si es uno de los tiles de Perú
        if any(tile in file["name"] for tile in tiles_peru):
            download_file(file["name"])

if __name__ == "__main__":
    try:
        main()
        print("\n✅ Descarga completada correctamente.")
    except Exception as e:
        print(f"❌ Error durante la descarga: {e}")




