#################################### 3.1 ####################################

import osmnx as ox
import geopandas as gpd

# 1. Obtener polígono del Perú
peru = ox.geocode_to_gdf("Peru")

# 2. Definir tags para buscar en OSM
tags = {
    "boundary": "protected_area",
    "leisure": "nature_reserve",
    "protect_class": True
}


# 3. Descargar features con esos tags dentro de Perú
gdf = ox.features_from_polygon(peru.geometry.iloc[0], tags)
base = gdf.copy()

# 4. Filtrar geometrías tipo polígono
base = base[base.geometry.type.isin(["Polygon", "MultiPolygon"])]

# 5. Filtrar por protect_class válido
valid_classes = {"2", "4", "6"}
base_filtrada = base[base["protect_class"].isin(valid_classes)]

# 6. Añadir ID único por parque
base_filtrada = base_filtrada.reset_index(drop=True)
base_filtrada["park_id"] = base_filtrada.index

# 7. Guardar como GeoPackage
base_filtrada.to_file("peru_protected_areas.gpkg", driver="GPKG")
print("✅ Archivo guardado como peru_protected_areas.gpkg")



import geopandas as gpd
gdf = gpd.read_file("peru_protected_areas.gpkg")
gdf.head()

#################################### 3.2 #################################### 
##### paso 1 #####
import os
import requests

# Crea una carpeta para guardar los archivos
os.makedirs("MODIS_tiles", exist_ok=True)

# Credenciales de Earthdata (REEMPLAZA ESTOS VALORES POR LOS TUYOS)
username = "ja.zambrano07"
password = "An071001159857@"

# Tiles MODIS que cubren Perú (estimación visual; puede ajustarse)
tiles = ["h10v09", "h10v10", "h11v09", "h11v10"]

# Base URL del repositorio MODIS MOD44B v061, año 2024
base_url = "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/61/MOD44B/2024"

# Lista de días julianos disponibles (uno por mes es suficiente)
days = ["001", "097", "193", "289"]  # Jan, Apr, Jul, Oct

# Descarga los archivos HDF
for tile in tiles:
    for day in days:
        filename = f"MOD44B.A2024{day}.{tile}.061.202xxxxxx.hdf"
        url = f"{base_url}/{day}/{filename}"
        print(f"Descargando {filename}...")

        response = requests.get(url, auth=(username, password), stream=True)
        if response.status_code == 200:
            with open(f"MODIS_tiles/{filename}", "wb") as f:
                f.write(response.content)
            print(f"✅ Guardado: {filename}")
        else:
            print(f"⚠️ No se pudo descargar: {filename} ({response.status_code})")

##### paso 2 #####

import rioxarray
import xarray as xr
import glob

# Leer todos los archivos .hdf descargados
files = glob.glob("MODIS_tiles/*.hdf")

#faltaba cargar conda install -c conda-forge rioxarray -y
import rioxarray
print(rioxarray.__version__)

# Cargar solo la capa Percent_Tree_Cover
datasets = []
for file in files:
    print(f"Procesando {file}")
    ds = rioxarray.open_rasterio(
        file,
        variable="Percent_Tree_Cover",
        mask_and_scale=True,
        chunks=True
    )
    datasets.append(ds)

# Hacer mosaico (merge)
mosaic = xr.combine_by_coords(datasets)

# Reproyectar a EPSG:4326
mosaic = mosaic.rio.reproject("EPSG:4326")

# Guardar a GeoTIFF
mosaic.rio.to_raster("vcf_2024_peru.tif")
print("✅ Raster guardado como vcf_2024_peru.tif")













